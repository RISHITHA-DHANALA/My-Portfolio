import { useEffect, useState } from "react";
import ThemeStudio from "./ThemeStudio.jsx";
import { site } from "../data/siteData.js";
export const NAV = [["about", "About"], ["projects", "Projects"], ["playground", "Playground"], ["resume", "Resume"], ["contact", "Contact"]];
export default function Nav({ theme, setTheme, view }) {
  const [active, setActive] = useState("");
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (view === "playground") { setActive("playground"); return; }
    const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setActive(e.target.id)), { rootMargin: "-45% 0px -50% 0px" });
    ["home", ...NAV.map((n) => n[0])].forEach((id) => { const el = document.getElementById(id); el && io.observe(el); });
    return () => io.disconnect();
  }, [view]);
  return (
    <header className="nav glass">
      <div className="wrap">
        <a className="logo" href="#home">{site.name}</a>
        <nav aria-label="Main">
          <ul className={`links ${open ? "open" : ""}`}>
            {NAV.map(([id, label]) => (
              <li key={id}><a href={`#${id}`} aria-current={active === id} onClick={() => setOpen(false)}>{label}</a></li>
            ))}
          </ul>
        </nav>
        <div className="nav-right">
          <ThemeStudio theme={theme} setTheme={setTheme} />
          <button className="iconbtn burger" aria-expanded={open} aria-label="Toggle menu" onClick={() => setOpen(!open)}>{open ? "Close" : "Menu"}</button>
        </div>
      </div>
    </header>
  );
}