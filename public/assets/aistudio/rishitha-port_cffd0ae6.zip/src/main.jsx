import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'
import '@/styles/themes.css'
import '@/styles/global.css'
import '@/styles/game.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)