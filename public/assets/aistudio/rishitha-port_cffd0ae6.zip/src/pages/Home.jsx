import { useEffect, useState } from "react";
import Nav from "../components/Nav.jsx";
import Hero from "../sections/Hero.jsx";
import { About, Education, Skills, Projects, Achievements, Interests } from "../sections/Content.jsx";
import Playground from "../sections/Playground.jsx";
import ResumeCta from "../sections/ResumeCta.jsx";
import Contact from "../sections/Contact.jsx";
import Footer from "../sections/Footer.jsx";
import { readTheme, saveTheme } from "../themes/themes.js";

const isPlayground = () => window.location.hash === "#playground";

export default function Home() {
  const [theme, setTheme] = useState(readTheme);
  const [view, setView] = useState(() => (isPlayground() ? "playground" : "portfolio")); // the game stays hidden until Playground is chosen
  useEffect(() => {
    document.documentElement.dataset.palette = theme.palette;
    document.documentElement.dataset.mode = theme.mode;
    saveTheme(theme);
  }, [theme]);
  useEffect(() => {
    const sync = () => setView(isPlayground() ? "playground" : "portfolio");
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);
  useEffect(() => {
    if (view === "playground") { window.scrollTo(0, 0); return; }
    const id = window.location.hash.slice(1);
    const el = id && document.getElementById(id);
    if (el) el.scrollIntoView(); else if (!id) window.scrollTo(0, 0);
  }, [view]);
  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <Nav theme={theme} setTheme={setTheme} view={view} />
      <main id="main">
        {view === "playground" ? (
          <Playground onBack={() => { window.location.hash = "#home"; }} />
        ) : (
          <><Hero /><About /><Education /><Skills /><Projects /><Achievements /><Interests /><ResumeCta /><Contact /></>
        )}
      </main>
      <Footer />
    </>
  );
}