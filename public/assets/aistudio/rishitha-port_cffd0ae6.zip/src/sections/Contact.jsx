import { useState } from "react";
import Section from "../components/Section.jsx";
import { site } from "../data/siteData.js";
const ENDPOINT = import.meta.env.VITE_FORM_ENDPOINT;
const CONFIGURED = /^https:\/\/formspree\.io\/f\/[A-Za-z0-9]+$/.test(ENDPOINT || "");
function F({ k, label, type = "text", area, errs }) {
  const P = area ? "textarea" : "input";
  return (
    <div>
      <label htmlFor={`f-${k}`}>{label}</label>
      <P id={`f-${k}`} name={k} type={area ? undefined : type} rows={area ? 5 : undefined} required aria-required="true" aria-invalid={!!errs[k]} aria-describedby={errs[k] ? `e-${k}` : undefined} autoComplete={k === "name" || k === "email" ? k : "off"} />
      {errs[k] && <p className="err" id={`e-${k}`}>{errs[k]}</p>}
    </div>
  );
}
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export default function Contact() {
  const [status, setStatus] = useState("idle");
  const [errs, setErrs] = useState({});
  const [msg, setMsg] = useState("");
  const submit = async (e) => {
    e.preventDefault();
    if (status === "sending") return;
    const form = e.currentTarget, data = new FormData(form), v = {};
    ["name", "email", "subject", "message"].forEach((k) => { if (!String(data.get(k) || "").trim()) v[k] = "This field is required."; });
    if (!v.email && !EMAIL_RE.test(String(data.get("email")).trim())) v.email = "Enter a valid email address.";
    setErrs(v);
    if (Object.keys(v).length) return;
    setStatus("sending"); setMsg("");
    try {
      const r = await fetch(ENDPOINT, { method: "POST", headers: { Accept: "application/json" }, body: data });
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.errors?.map((x) => x.message).join(", ") || "The server rejected the message."); }
      setStatus("sent"); form.reset();
    } catch (err) { setStatus("error"); setMsg(err.message || "Network error."); }
  };
  return (
    <Section id="contact" title="Contact">
      <p>Have a question or an opportunity in mind? Send a message and I'll reply by email.</p>
      {!CONFIGURED ? (
        <p className="setup" role="note">The contact form is unavailable because <code>VITE_FORM_ENDPOINT</code> is missing or is not a valid Formspree URL. You can reach me on <a className="lnk" href={site.links.linkedin} target="_blank" rel="noopener noreferrer">LinkedIn</a> instead.</p>
      ) : (
        <form className="form" onSubmit={submit} noValidate>
          <F errs={errs} k="name" label="Name" /><F errs={errs} k="email" label="Email" type="email" /><F errs={errs} k="subject" label="Subject" /><F errs={errs} k="message" label="Message" area />
          <button className="btn primary" disabled={status === "sending"} aria-busy={status === "sending"}>{status === "sending" ? "Sending..." : "Send message"}</button>
          <div role="status" aria-live="polite">
            {status === "sent" && <p className="ok">Thank you. Your message was sent.</p>}
            {status === "error" && <p className="err">Message not sent: {msg} Please try again, or use LinkedIn.</p>}
          </div>
        </form>
      )}
    </Section>
  );
}
