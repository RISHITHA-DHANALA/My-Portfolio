import Section from "../components/Section.jsx";
import { site, education, skills, projects, achievements, interests } from "../data/siteData.js";
export const About = () => (
  <Section id="about" title="About me">
    {[...site.about, site.aboutExtra].filter(Boolean).map((t, i) => <p key={i}>{t}</p>)}
    {site.location && <p className="muted">Based in {site.location}</p>}
  </Section>
);
export const Education = () => (
  <Section id="education" title="Education">
    {education.map((e) => (
      <div className="row" key={e.degree}>
        <h3>{e.degree}</h3>
        <p>{e.school}</p>
        {e.years && <p className="muted">{e.years}</p>}
        {e.note && <p className="muted">{e.note}</p>}
      </div>
    ))}
  </Section>
);
export const Skills = () => (
  <Section id="skills" title="Technical skills">
    <div className="cols">
      {skills.map((g) => (
        <div key={g.group}><h3>{g.group}</h3><ul>{g.items.map((s) => <li key={s}>{s}</li>)}</ul></div>
      ))}
    </div>
  </Section>
);
export const Projects = () => (
  <Section id="projects" title="Projects">
    {projects.map((p) => (
      <article className="row" key={p.title}>
        <h3>{p.title}</h3>
        <p className="muted">{p.description}</p>
        <ul className="tags" aria-label="Technologies">{p.tech.map((t) => <li key={t}>{t}</li>)}</ul>
        <p className="plinks">
          {p.links.map((l) => <a key={l.href} className="lnk" href={l.href} target="_blank" rel="noopener noreferrer">{l.label}<span className="sr"> (opens in a new tab)</span></a>)}
        </p>
      </article>
    ))}
  </Section>
);
export const Achievements = () => (
  <Section id="achievements" title="Achievements">
    {achievements.map((a) => (
      <div className="row" key={a.title}>
        <p className="big">{a.title}</p>
        <p className="muted">{a.detail}</p>
      </div>
    ))}
  </Section>
);
export const Interests = () => (
  <Section id="interests" title="Learning and interests">
    <ul className="icards">
      {interests.map((i) => (
        <li key={i.title} className="icard glass">
          <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={i.icon} /></svg>
          <span>{i.title}</span>
          {i.status && <em className="status">{i.status}</em>}
        </li>
      ))}
    </ul>
  </Section>
);
