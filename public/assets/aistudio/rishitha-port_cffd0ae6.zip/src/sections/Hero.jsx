import { useEffect, useRef } from "react";
import { site } from "../data/siteData.js";
import GravityWord from "../components/GravityWord.jsx";
const TAGS = [["C", "4%", "6%", 40, 0], ["Java", "64%", "2%", 64, 1], ["Python", "80%", "46%", 34, 2], ["HTML", "2%", "52%", 56, 3], ["CSS", "44%", "90%", 30, 4], ["JavaScript", "62%", "80%", 60, 5], ["DSA", "22%", "36%", 46, 1.5]];
export default function Hero() {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const move = (e) => {
      if (e.pointerType === "touch") return;
      const r = el.getBoundingClientRect();
      el.style.setProperty("--mx", (((e.clientX - r.left) / r.width) * 2 - 1).toFixed(3));
      el.style.setProperty("--my", (((e.clientY - r.top) / r.height) * 2 - 1).toFixed(3));
    };
    const leave = () => { el.style.setProperty("--mx", 0); el.style.setProperty("--my", 0); };
    el.addEventListener("pointermove", move); el.addEventListener("pointerleave", leave);
    return () => { el.removeEventListener("pointermove", move); el.removeEventListener("pointerleave", leave); };
  }, []);
  const L = (d, cls, style, kids) => <div key={`${cls}${d}${style.left || ""}`} className={`L ${cls}`} style={{ "--d": d, ...style }}>{kids}</div>;
  return (
    <section id="home" className="hero" ref={ref} aria-label="Introduction">
      <div className="wrap">
        <div>
          <GravityWord text="Portfolio" />
          <p className="muted">{site.role}</p>
          <GravityWord as="h1" className="name" text={site.name} />
          <p className="lead">{site.intro}</p>
          <div className="cta">
            <a className="btn primary" href="#projects">View projects</a>
            <a className="btn" href="#contact">Get in touch</a>
          </div>
        </div>
        <div className="stage" aria-hidden="true">
          {L(-20, "orb", {})}
          {L(-40, "ring", {}, <svg viewBox="0 0 200 200" className="fl spin"><circle cx="100" cy="100" r="92" fill="none" stroke="currentColor" strokeDasharray="4 8" /><circle cx="100" cy="100" r="62" fill="none" stroke="currentColor" opacity=".5" /></svg>)}
          {L(-26, "cube", {}, <div className="fl" style={{ "--t": "1s" }} />)}
          {L(18, "tilt code a glass", {}, <pre><b>def </b><i>explain</i><b>(scan):</b>{"\n"}<b>  return </b><i>heatmap</i><b>(scan)</b></pre>)}
          {L(30, "tilt code b glass", {}, <pre><b>for </b><i>topic</i><b> in </b>{'["DSA", "AI/ML"]:'}{"\n"}<b>  learn(topic)</b></pre>)}
          {L(48, "info i1 glass", {}, <span className="fl">Java · OOP · file handling</span>)}
          {L(58, "info i2 glass", {}, <span className="fl" style={{ "--t": "2s" }}>Python · Streamlit · OpenCV</span>)}
          {TAGS.map(([t, l, tp, d, dl]) => L(d, "", { left: l, top: tp }, <span key={t} className="tag fl" style={{ "--t": `${dl}s` }}>{t}</span>))}
        </div>
      </div>
    </section>
  );
}
