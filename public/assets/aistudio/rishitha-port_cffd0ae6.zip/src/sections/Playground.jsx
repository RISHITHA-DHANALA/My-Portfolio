import { useState } from "react";
import Section from "../components/Section.jsx";
import MissingFileGame from "../game/components/MissingFileGame.jsx";
import OrbitEscape from "./OrbitEscape.jsx";

export default function Playground({ onBack }) {
  const [game, setGame] = useState("missing-file");
  return (
    <Section id="playground" title="Playground">
      <div className="pg-top">
        <button className="btn" onClick={onBack}>Back to portfolio</button>
        <div className="pg-switch" role="tablist" aria-label="Choose a game">
          <button
            role="tab"
            aria-selected={game === "missing-file"}
            className={game === "missing-file" ? "on" : ""}
            onClick={() => setGame("missing-file")}
          >Missing Case</button>
          <button
            role="tab"
            aria-selected={game === "orbit"}
            className={game === "orbit" ? "on" : ""}
            onClick={() => setGame("orbit")}
          >Orbit Escape</button>
        </div>
      </div>
      {/* both games stay mounted so an unfinished case survives the tab switch */}
      <div style={{ display: game === "missing-file" ? undefined : "none" }}><MissingFileGame /></div>
      <div style={{ display: game === "orbit" ? undefined : "none" }}><OrbitEscape /></div>
    </Section>
  );
}