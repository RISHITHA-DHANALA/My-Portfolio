import { site } from "../data/siteData.js";
export default function ResumeCta() {
  return (
    <section id="resume" className="rcta" aria-labelledby="rcta-h">
      <div className="wrap">
        <div>
          <h2 id="rcta-h">Looking for the next problem to learn from.</h2>
          <p>I'm open to genuine internship opportunities where I can contribute as a student developer, learn from an experienced team, and work on real software problems. Remote roles work especially well right now since I'm a full-time student.</p>
        </div>
        <a className="rcta-btn" href={import.meta.env.BASE_URL + site.resumePath} download="Rishitha-Dhanala-Resume.pdf">Download Resume</a>
      </div>
    </section>
  );
}
